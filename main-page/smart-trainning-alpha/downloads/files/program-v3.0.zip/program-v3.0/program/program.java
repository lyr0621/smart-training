import javax.swing.JOptionPane;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileNotFoundException;      //导入要用的库

public class program {
    public static void main(String[] args) throws Exception{
        test_now();
        test_now();
        test_now();
    }

    public static String[] read(String filename) throws Exception {    //读取文件，参数filename表示文件的名称
        String path = "题库/" + filename;       //设置路径
        FileInputStream fileInputStream = new FileInputStream(path);     //新建fileinputstream对象，用于打开文件

        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));        //新建bufferedReader对象，用于读取文件

        String line = null;    //表示目前正在读取的行

        String result = "";    //用来存储读取文件的结果

        while ((line = bufferedReader.readLine()) != null) {
            result += line + "/";     //将结果存入result，以"/为间隔"
        }

        fileInputStream.close();   //关闭文件

        result = result.trim();     //去掉没有内容的行

        return result.split("/");     //以“/”为间隔再把result拆开并返回，因此返回的是一个字符串列表，表示每一行的数据
    }

    public static void write(String filename, String line, boolean replace) throws Exception {   //写入单行文件，参数filename表示文件名，line表示要写入的行，replace表示是否要覆盖原来的文件
        String path = "题库/" + filename;    //设置路径
        File file = new File(path);      //创建file类型文件
        String[] old_file = new String[0];       //创建列表old_file用于存储原来的文件
        if (!replace) {          //如果不需要覆盖原来的文件
            try {
                old_file = read(filename);      //读取文件，存入列表old_file
            } catch(FileNotFoundException e) {}     //如果没找到该文件，什么都不用做，当新文件处理
        }
        

        String[] content = new String[old_file.length+1];     //创建列表content，用于存储要写入的东西，长度时old_file的长度加一(因为是写入单行文件)

        for (int i = 0; i<old_file.length; i++) {
            content[i] = old_file[i];    //将 oldfile中的项都复制给content
        }

        content[old_file.length] = line;    //content的最后一项(也就是第old_file.length项，因为其长度为old_file.length＋1)

        FileOutputStream fileOutputStream = new FileOutputStream(file);   //新建写入文件的对象
        for (int i = 0; i<content.length; i++) {
            if (content[i] != ""){
                fileOutputStream.write(content[i].getBytes());    //写入
                fileOutputStream.write('\n');   //换行
            }
        }

        fileOutputStream.close();   //关闭文件
    }
    public static void write(String filename,  String line) throws Exception {    //如果没有说明是否要覆盖文件的话
        write(filename,line,false);   //不覆盖文件
    }
    public static void write(String filename, String[] lines, boolean replace) throws Exception {   //写入多行文件，传入的参数lines是一个列表，表示要写入的行(不止一行)
        if (replace) {     //如果要覆盖
            write(filename, "", true);     //先覆盖原来的文件，并写入空字符(相当于把原来的文件变成了空的)
            for (int i = 0; i<lines.length; i++) {
                write(filename,lines[i]);    //一行行写入
            }
        }
        else {   //不用覆盖
            for (int i = 0; i<lines.length; i++) {
                write(filename,lines[i]);    //一行行写入
            }
        }
        
    }
    public static void write(String filename, String[] lines) throws Exception {    //写入多行文件，没有说明是否要覆盖时
        write(filename, lines, false);    //不覆盖
    }

    public static void creat_new_question_type_in_mistake_book(String qtype) throws Exception {   //在错题本中新增错题类型并初始化
        write("../错题本",qtype + ":" + "0");      //错题本的格式:     题类名称:当前等级
    }

    public static void intiliaze_mistake_book() throws Exception {   //重置错题本至初始状态
        String[] old_file = read("../错题本");         //先读取之前的错题本
        String[] new_file = new String[old_file.length];       //创建空列表new_file，使其长度为之前错题本的长度
        for (int i = 0; i < old_file.length; i++) {
            new_file[i] = old_file[i].split(":")[0] + ":0";       //每一种错题初始的等级都是0级
        }
        write("../错题本",new_file,true);      //写入文件
    }

    public static void del_question_type_in_mistake_book(String qtype) throws Exception {     //在错题本中删除一个错题类型
        String[] old_file = read("../错题本");     //读取原来的错题本
        String[] new_file = new String[old_file.length];     //创建列表new_file，其长度为原来错题本的长度－1
        for (int i = 0; i < old_file.length; i++) {
            if (old_file[i].split(":")[0].equals(qtype)) {     //如果时我们要删除的这一项
                new_file[i] = null;    //为空，也就是从新错题本中删除
            } else{     //如果是其他的
                new_file[i] = old_file[i];       //原封不动放进new_file中
            }
        }
        write("../错题本",get_indexed_items(new_file),true);    //写入文件，用函数getindexeditem删除了的错题(因为刚刚将它设为了空)
    }

    public static void add_level_for_question_in_mistake_book(String qtype) throws Exception {   //将错题本中某一个题类的掌握等级提升1级
        String[] old_file = read("../错题本");     //先读取原来的错题本
        String[] new_file = new String[old_file.length];       //新建列表new_file，长度和old_file一样
        int level;   //level表示当前题目的等级
        for (int i = 0; i < old_file.length; i++) {
            if (old_file[i].split(":")[0].equals(qtype)) {       //找到该问题
                if (old_file[i].split(":")[1].equals("3")) {    //如果该问题目前等级是三级
                    del_question_type_in_mistake_book(qtype);    //删除该问题
                    return;   //退出函数
                }
                else {      //不是三级
                    level = Integer.parseInt(old_file[i].split(":")[1]);    //提取当前的等级数
                    level++;      //将等级数加一
                    new_file[i] = old_file[i].split(":")[0] + ":" + level;    //存入new_file中
                }
            }
            else {    //如果不是我们要找到问题
                new_file[i] = old_file[i];     //原封不动的存入new_file
            }
        }


        write("../错题本",get_indexed_items(new_file),true);    //写入文件
    }

    public static String[] read_mistake_book() throws Exception {      //读取错题本
        return read("../错题本");    //读取文件
    }

    public static void add_did_times_for_question(String qtype, String question) throws Exception{     //在题库中增加某题类的某题型做过的次数,qtype为题目类型，question为题目的问题
        String[] old_file = read(qtype);     //读取原来的文件
        String[] new_file = new String[old_file.length];     //创建列表new_file，并开辟内存空间，长度与old_file一样
        int did_times, wrong_times;         //did_times用于表示做过的次数，wrong_times用于表示错误次数
        for (int i = 0; i < old_file.length; i++) {     //遍历原来的文件
            if (old_file[i].split(":")[0].equals(question)) {     //找到我们要修改的那一个题目
                did_times = Integer.valueOf(old_file[i].split(":")[2]);     //提取做过的次数
                did_times++;    //增加做过的次数（加一）
                wrong_times = Integer.valueOf((old_file[i].split(":")[3]));    //提取错误次数，不需要改变
                new_file[i] = old_file[i].split(":")[0] + ":" + old_file[i].split(":")[1] + ":" + did_times + ":" + wrong_times;    //合并，并存入new_file中
                continue;   //跳过循环，下面的这行的代码就不会被执行
            }
            new_file[i] = old_file[i];    //如果不是我们要找的题，直接原样照搬
        }
        write(qtype,new_file,true);    //写入文件，并替换以前的文件
    }

    public static void add_wrong_times_for_question(String qtype, String question) throws Exception{     //在题库中增加某题类的某题型的错误次数,qtype为题目类型，question为题目的问题
        String[] old_file = read(qtype);
        String[] new_file = new String[old_file.length];
        int did_times, wrong_times;
        for (int i = 0; i < old_file.length; i++) {
            if (old_file[i].split(":")[0].equals(question)) {
                did_times = Integer.valueOf(old_file[i].split(":")[2]);
                wrong_times = Integer.valueOf((old_file[i].split(":")[3]));
                wrong_times++;     //改变错误次数，不改变做过的次数
                new_file[i] = old_file[i].split(":")[0] + ":" + old_file[i].split(":")[1] + ":" + did_times + ":" + wrong_times;
                continue;
            }
            new_file[i] = old_file[i];
        }
        write(qtype,new_file,true);
        //所有部分都与add_did_times_for_question相同，除了167行
    }

    public static String input(String question, String title) {     //使用对话框询问
        String result = JOptionPane.showInputDialog(null, question, title, JOptionPane.INFORMATION_MESSAGE);   //使用对话框询问
        if (result == null) {    //如果result未被赋值(原因是用户关闭了对话框)
            return "";     //返回空字符
        }
        return result;    //返回用户给的回答
    }
    public static String input(String question) {  //只给一个参数时
        return input(question,"please input...");     //标题设为please input...
    }

    public static void print(String line, String title, String type) {   //用提示框打印字符，参数line是要打印的内容，title是提示框的标题，type是提示框的类型
        int type_id;    //type_id表示提示框的类型
        if (type == "error") {    //如果参数type为error
            type_id = JOptionPane.ERROR_MESSAGE;     //设置type_id为报错提示框的id
        } else if (type == "normal") {      //如果类型是normal
            type_id = JOptionPane.INFORMATION_MESSAGE;     //设置type_id为正常提示框
        } else {   //既不是normal也不是error
            type_id = JOptionPane.INFORMATION_MESSAGE;    //也设为type_id为正常提示框
        }
        JOptionPane.showMessageDialog(null, line, title, type_id);    //弹出提示框
    }
    public static void print(String line, String title) {   //只给两个参数时
        print(line,title,"normal");     //type为normal
    }
    public static void print(String line) {    //只给一个参数时
        print(line, "程序提示您");    //title为“程序提示您”
    }

    public static String judge(int score) {     //输入成绩，给出反馈
        if (score > 95) {
            return "真是奇才啊，牛逼";
        } else if (score > 90) {
            return "很厉害啊！";
        } else if (score > 80) {
            return "很不错呢！";
        } else if (score > 75) {
            return "还行.";
        } else if (score > 60) {
            return "还需多加练习哦！";
        } else if (score > 20) {
            return "呜呜～不及格哦，小心回家被扇巴掌哦(*_*)";
        } else {
            return "你是来捣乱的吧～";
        }
    }

    public static void new_question() throws Exception{    //新建问题
        String qtype = input("问题的类型是什么？","请输入问题类型");    //询问问题的类型
        int question_difficulty;     //表示题目的难度等级
        try {
            question_difficulty = Integer.valueOf(input("难度等级是什么（难度等级需在1-3级之间）","请输入难度等级"));   //询问问题难度等级，强制转化为int类型
        } catch(NumberFormatException e) {    //如果输入的不是纯数字而报错
            print("请输入纯数字（整数）","错误","error");    //提示输入纯数字
            return;   //退出函数
        }
        if (question_difficulty > 3 | question_difficulty < 1) {    //如果问题难度等级高于三或小于一
            print("数字需在1-3之间","错误","error");    //提示要在一至三之间
            return;    //推出函数
        }
        String question = input("问题是什么？");     //询问问题是什么
        String answer = input("正确答案是什么？");    //询问答案是什么
        switch(question_difficulty) {          //设置初始的题目回答次数以及答错次数
            case 1 :{
                write(qtype,question + ":" + answer + ":8:1");    //一级题目的错误比例为0.25及以下（包括0.25）
                break;
            }
            case 2 :{
                write(qtype,question + ":" + answer + ":8:3");    //二级题目的错误比例为0.25-0.5（包括0.5）
                break;
            }
            case 3 :{
                write(qtype,question + ":" + answer + ":8:5");    //三级题目的错误比例为0.5以上
                break;
            }
        }
    }

    public static String[] get_indexed_items(String[] list) {   //提取列表中内容不为空的项
        int indexed_items_num = 0;     //表示该列表中有多少个项是不为空的
        for (int i = 0; i < list.length; i++) {
            if (list[i] != null & list[i] != "") {    //如果内容不为空
                indexed_items_num++;     //增加一
            }
        }
        String[] indexed_item = new String[indexed_items_num];    //indexed_item表示有内容的项
        int num = 0;    //表示目前indexed_item用到第几项了
        for (int i = 0; i < list.length; i++) {   //遍历 
            if (list[i] != null & list[i] != "") {    //只要这一项不是空
                indexed_item[num] = list[i];    //放到indexed_item中
                num++;
            }
        }
        return indexed_item;    //返回有内容的项
    }

    public static void test_now() throws Exception{   //开始测试
        print("您开始了新一轮的测试");
        String[] mistake_book = get_indexed_items(read_mistake_book());     //读取错题本
        if (mistake_book.length == 0) {       // 如果错题本为空
            print("目前题库中已经找不到能够难倒你的题目了，快去玩吧！","恭喜你!!!");     //错题本为空表示该用户没有不完全掌握的题型了
            return;    //推出函数
        }

        int right_times = 0;     //表示做对了几题
        int question_number = 0;    //表示第几题
        String[] solved_problems = new String[mistake_book.length];      //用于存储已经解决的错题，长度和 mistakebook一样长，因为这是可能解决的题型的数量上限
        int solved_problems_num = 0;    //表示该列表用到第几项了
        String[] wrong_answers = new String[mistake_book.length];       //用于存储做错的题目
        int wrong_answers_num = 0;    //表示该列表用到第几项了
        String[] question_source, question, list1;                     //用于存储该题类的文件中的内容，存储问题和找到符合要求的题型
        int list1_num = 0;   //表示该列表用到第几项了
        int r;     //用于制造随机数
        int questions_did_times, questions_wrong_times;
        String my_answer;    //用于存储我的答案
        for (int i = 0; i < mistake_book.length; i++) {     //遍历错题本
            if (mistake_book[i] == "") {     //如果这一项的内容为空(可能是字符串处理时导致的)
                continue;    //跳过
            }
            question_number++;    //问题题号加一

            if (mistake_book[i].split(":")[1].equals("0")) {       //如果该题类目前的掌握情况为0级
                question_source = read(mistake_book[i].split(":")[0]);       //先读取该题类的文件
                list1 = new String[question_source.length];
                list1_num = 0;
                for (int m = 0; m < question_source.length; m++) {    //遍历题类的文件
                    questions_did_times = Integer.valueOf(question_source[m].split(":")[2]);    //提取出该题目做过的次数
                    questions_wrong_times = Integer.valueOf(question_source[m].split(":")[3]);    //提取出该题目错误的次数
                    if ((double) questions_wrong_times/(double) questions_did_times > 0.5) {      //找到符合条件(难度等级为3)的题目，错误频率大于0.5
                        list1[list1_num] = question_source[m];     //存入list1
                        list1_num++;    //这个是为了记住list1已经存到第几项了，因为java没有append
                    }
                }
                question_source = get_indexed_items(list1);    //提取list1中不为空的项，存入question_source

                if (question_source.length == 0) {
                    print("抱歉，题库不全，对于“" + mistake_book[i].split(":")[0] + "”这个类型没有适合您目前的掌握等级(" + mistake_book[i].split(":")[1] + ")没有合适的题目，将跳过到下一题","错误：找不到合适的题目","error_message");
                    continue;
                }
                
                r = (int) (Math.random()*question_source.length);    //在零到符合条件的题目数量之间随机一个数，并强制转化为int
                question = question_source[r].split(":");        //提取随机到的那一项，并以“:”为间隔拆分称列表，存入question中，格式 问题:正确答案:难度等级
                
                add_did_times_for_question(mistake_book[i].split(":")[0], question[0]);    //增加这题的回答次数

                my_answer = input(question[0],"题目"+question_number+"/"+mistake_book.length);       //提问题，把答案存入my_answer中

                if (my_answer.equals(question[1])) {    //回答正确
                    right_times++;    //正确次数加一
                    //因为目前该题类的掌握情况是零级，所以一旦答对就可以直接从错题本中删除
                    solved_problems[solved_problems_num] = mistake_book[i].split(":")[0] + ":" + question[0] + ":" + question[1];      //存入solved_problem列表中，格式：   题类名称:问题:答案
                    solved_problems_num++;
                    print("恭喜你，答对了！");
                    del_question_type_in_mistake_book(mistake_book[i].split(":")[0]);     //从错题本中删除
                    
                }
                else {     //回答错误
                    print("很抱歉，你答错了");
                    wrong_answers[wrong_answers_num] = mistake_book[i].split(":")[0] + ":" + question[0] + ":" + question[1] + ":" + my_answer;     //存入wrong_answers中，格式：  题目类型:问题:正确答案:我的答案
                    wrong_answers_num++;
                    add_level_for_question_in_mistake_book(mistake_book[i].split(":")[0]);    //在错题本中为这个题类的掌握等级加一(从零级变成一级)
                    add_wrong_times_for_question(mistake_book[i].split(":")[0], question[0]);      //增加这题的错误次数
                }
            }

            else if (mistake_book[i].split(":")[1].equals("1")) {    //目前掌握程度为一级
                question_source = read(mistake_book[i].split(":")[0]);
                list1 = new String[question_source.length];
                list1_num = 0;
                for (int m = 0; m < question_source.length; m++) {
                    questions_did_times = Integer.valueOf(question_source[m].split(":")[2]);
                    questions_wrong_times = Integer.valueOf(question_source[m].split(":")[3]);
                    if ((double) questions_wrong_times/(double) questions_did_times <= 0.25) {    //一级的错误频率小于等于0.25
                        list1[list1_num] = question_source[m];
                    }
                }
                question_source = get_indexed_items(list1);

                if (question_source.length == 0) {
                    print("抱歉，题库不全，对于“" + mistake_book[i].split(":")[0] + "”这个类型没有适合您目前的掌握等级(" + mistake_book[i].split(":")[1] + ")没有合适的题目，将跳过到下一题","错误：找不到合适的题目","error_message");
                    continue;
                }
                
                r = (int) (Math.random()*question_source.length);
                question = question_source[r].split(":");

                add_did_times_for_question(mistake_book[i].split(":")[0], question[0]);
                
                my_answer = input(question[0],"题目"+question_number+"/"+mistake_book.length);
                //以上部分与刚刚的代码一样

                if (my_answer.equals(question[1])) {    //回单正确
                    right_times++;
                    print("恭喜你，答对了！");
                    add_level_for_question_in_mistake_book(mistake_book[i].split(":")[0]);     //掌握程度的等级加一
                }
                else {    //回答错误
                    print("很抱歉，你答错了");
                    //掌握程度不变
                    wrong_answers[wrong_answers_num] = mistake_book[i].split(":")[0] + ":" + question[0] + ":" + question[1] + ":" + my_answer;     //存入wrong_answers中
                    wrong_answers_num++;
                    add_wrong_times_for_question(mistake_book[i].split(":")[0], question[0]);    //增加这题的回答次数
                }
            }

            else if (mistake_book[i].split(":")[1].equals("2")) {     //二级
                question_source = read(mistake_book[i].split(":")[0]);
                list1 = new String[question_source.length];
                list1_num = 0;
                for (int m = 0; m < question_source.length; m++) {
                    questions_did_times = Integer.valueOf(question_source[m].split(":")[2]);
                    questions_wrong_times = Integer.valueOf(question_source[m].split(":")[3]);
                    if ((double) questions_wrong_times/(double) questions_did_times > 0.25 & (double) questions_wrong_times/(double) questions_did_times <= 0.5) {    //二级的频率在0.25~0.5之间
                        list1[list1_num] = question_source[m];
                        list1_num++;
                    }
                }
                question_source = get_indexed_items(list1);

                if (question_source.length == 0) {
                    print("抱歉，题库不全，对于“" + mistake_book[i].split(":")[0] + "”这个类型没有适合您目前的掌握等级(" + mistake_book[i].split(":")[1] + ")没有合适的题目，将跳过到下一题","错误：找不到合适的题目","error_message");
                    continue;
                }
                
                r = (int) (Math.random()*question_source.length);
                question = question_source[r].split(":");

                add_did_times_for_question(mistake_book[i].split(":")[0], question[0]);    //增加这题的回答次数
                
                my_answer = input(question[0],"题目"+question_number+"/"+mistake_book.length);

                if (my_answer.equals(question[1])) {    //回答正确
                    right_times++;
                    print("恭喜你，答对了！");
                    add_level_for_question_in_mistake_book(mistake_book[i].split(":")[0]);      //等级加一
                    
                }
                else {    //错误
                    print("很抱歉，你答错了");
                    //等级不变
                    wrong_answers[wrong_answers_num] = mistake_book[i].split(":")[0] + ":" + question[0] + ":" + question[1] + ":" + my_answer;
                    wrong_answers_num++;
                    add_wrong_times_for_question(mistake_book[i].split(":")[0], question[0]);    //增加这题的回答次数
                }
            }

            else if (mistake_book[i].split(":")[1].equals("3")) {     //三级
                question_source = read(mistake_book[i].split(":")[0]);
                list1 = new String[question_source.length];
                list1_num = 0;
                for (int m = 0; m < question_source.length; m++) {
                    questions_did_times = Integer.valueOf(question_source[m].split(":")[2]);
                    questions_wrong_times = Integer.valueOf(question_source[m].split(":")[3]);
                    if ((double) questions_wrong_times/(double) questions_did_times > 0.5) {    //大于0.5
                        list1[list1_num] = question_source[m];
                        list1_num++;
                    }
                }
                question_source = get_indexed_items(list1);

                if (question_source.length == 0) {
                    print("抱歉，题库不全，对于“" + mistake_book[i].split(":")[0] + "”这个类型没有适合您目前的掌握等级(" + mistake_book[i].split(":")[1] + ")没有合适的题目，将跳过到下一题","错误：找不到合适的题目","error_message");
                    continue;
                }
                
                r = (int) (Math.random()*question_source.length);
                question = question_source[r].split(":");

                add_did_times_for_question(mistake_book[i].split(":")[0], question[0]);    //增加这题的回答次数
                
                my_answer = input(question[0],"题目"+question_number+"/"+mistake_book.length);

                if (my_answer.equals(question[1])) {    //正确
                    right_times++;
                    solved_problems[solved_problems_num] = mistake_book[i].split(":")[0] + ":" + question[0] + ":" + question[1] + ":" + my_answer;    //该问题就解决了
                    solved_problems_num++;
                    print("恭喜你，答对了！");
                    del_question_type_in_mistake_book(mistake_book[i].split(":")[0]);     //从错题本中删除该题类
                    
                }
                else {    //错误
                    print("很抱歉，你答错了");
                    //等级不变
                    wrong_answers[wrong_answers_num] = mistake_book[i].split(":")[0] + ":" + question[0] + ":" + question[1] + ":" + my_answer;
                    wrong_answers_num++;
                    add_wrong_times_for_question(mistake_book[i].split(":")[0], question[0]);    //增加这题的回答次数
                }
            }
        }

        print("考试结束，考试报告请在文本输出行中查看");

        System.out.println("在" + question_number + "道题目中，我做对了" + right_times + "道，正确率" + (right_times/question_number)*100 + "%，" + judge((right_times/question_number)*100));      //反馈正确率

        wrong_answers = get_indexed_items(wrong_answers);      //去除wrong_answers中为空的项

        if (wrong_answers.length != 0) {      //如果有错题的话
            System.out.println("\n\n\n\n\n\n\n\n\n\n\n <<--以下为错题分析-->>");
            for (int i = 0; i < wrong_answers.length; i++) {
                //wrong_answers的格式：   题目类型:问题:正确答案:我的答案
                System.out.println("<<第" + (i+1) + "道错题>>");
                System.out.println("问题类型：" + wrong_answers[i].split(":")[0]);
                System.out.println("问题：" + wrong_answers[i].split(":")[1]);
                System.out.println("我的答案：" + wrong_answers[i].split(":")[3]);
                System.out.println("正确答案：" + wrong_answers[i].split(":")[2]);
                System.out.println("\n");
            }
        }

        solved_problems = get_indexed_items(solved_problems);

        if (solved_problems.length != 0) {     //如果有已经彻底搞定的题型的话
            System.out.println("\n\n\n <<--恭喜你，你已经彻底解决了" + solved_problems.length + "个题型，它们是：-->>");
            //solved_problems的格式：   题类名称:问题:答案
            for (int i = 0; i < solved_problems.length; i++) {
                System.out.println("<<第" + (i+1) + "个题型>>");
                System.out.println(solved_problems[i].split(":")[0]);
            }
        }
    }
}