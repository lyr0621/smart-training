public class operater {
    public static void start() {
        String line;
        while (true) {
            line = io.input("enter your command>>");
            switch(line) {
                case "login": {
                    break;
                }
                case "logout": {
                    break;
                }
                case "newquestion" : {
                    break;
                }
                case "intilize" : {
                    break;
                }
                case "test_now" : {
                    break;
                }
            }
        }
    }
}
