这是天梯算法3.0，基于java开发

如果需要运行：
    (1) 安装java11或更高版本
    (2) 进入program文件夹，输入javac program.java; java program即可运行


#目前只是展示用，ui界面还没有开发完备，算法也还有待优化
<-天梯算法v3.0，2021.11.6，开发:lyr->