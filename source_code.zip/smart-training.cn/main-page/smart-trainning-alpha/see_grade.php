<?php
    echo "<p style='color: red'>THIS FUNCTION IS NOT AVALABLE YET!!! THIS IS ONLY A TEST PAGE</p>";
    echo "<h1>See Grade</h1>";
    echo "<p>Please enter your student ID and password to see your grade.</p>";
    echo "<form action='see_grade.php' method='post'>";
    echo "<p>Student ID: <input type='text' name='student_id'></p>";
    echo "<p>Password: <input type='password' name='password'></p>";
    echo "<p><input type='submit' value='Submit'></p>";
    echo "</form>";

?>